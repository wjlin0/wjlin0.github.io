from pyamf.remoting.gateway.wsgi import WSGIGateway

import logging

logger = logging.getLogger()
logger.setLevel(logging.DEBUG)  # 设置日志级别为 NOTSET

# 创建一个 StreamHandler 处理器并设置其级别为 DEBUG
stream_handler = logging.StreamHandler()
stream_handler.setLevel(logging.DEBUG)

# 创建一个格式化器并将其应用于处理器
formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
stream_handler.setFormatter(formatter)

# 将处理器添加到 logger
logger.addHandler(stream_handler)



ADMIN_USER = "??"
ADMIN_PASS = "??"


class FileManagerService:
    def read(self, filename):
        with open(filename, "rb") as f:
            return f.read()

    def list(self, path="/"):
        import os
        return os.listdir(path)


def auth(username, password):
    if username == ADMIN_USER and password == ADMIN_PASS:
        return True

    return False


gateway = WSGIGateway({"file_manager": FileManagerService}, authenticator=auth, logger=logger)


if __name__ == "__main__":
    from wsgiref import simple_server

    host = "0.0.0.0"
    port = 5000

    httpd = simple_server.WSGIServer((host, port), simple_server.WSGIRequestHandler)
    httpd.set_app(gateway)

    logger.info("Running Authentication AMF gateway on http://%s:%d" % (host, port))

    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
